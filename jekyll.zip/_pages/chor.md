---
layout: content
title: Chor - a chrome addict's best damn friend
permalink: /chor/
published: true
tags: 'chor'
---

#### A new kind of tab/group/window switcher/manager for Google Chrome

---
