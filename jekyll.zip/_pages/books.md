---
layout: content
title: Books and Writings
permalink: /books/
published: true
tags: "personal, career, writings, books"
---

-   [The key to study skills](https://amzn.to/2Bsgj1D) - Simple Strategies to Double Your Reading, Memory, and Focus (With Lev and Anna Goldentouch)

-   [The Escapist's Propaganda](https://amzn.to/33NlMfR) - An anthology of my poems

-   Some of what I wrote for the financial news wire [NSE Cogencis](http://www.cogencis.com), can be read on [Muckrack](http://www.muckrack.com/surajsharma)

-   A [Short Story](https://issuu.com/differsense/docs/reading_hour_jan-feb_2013) published in the [Jan-Feb 2013](https://amzn.to/3dvTXmj) issue of the Indian literary magazine [Reading Hour](https://bit.ly/3SMnZSV)

-   [Old poetry and essays](https://surajsharma.blogspot.in/)

- [singularity](https://evenzero.in/singularity/) - a public zettelkasten

-   Casual [Goodreads](https://bit.ly/3dulkwS) profile for the curious