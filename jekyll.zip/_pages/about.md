---
layout: content
title: About
permalink: /about/
published: true
tags: "personal, career, hobbies"
---

the state looks down on sodomy.

![](http://i.imgur.com/LjcPv.png) ![](http://i.imgur.com/cNKvt.png)

---
